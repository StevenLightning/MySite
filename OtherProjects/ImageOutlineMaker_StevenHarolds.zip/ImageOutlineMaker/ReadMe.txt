Program created by Steven Harolds

Run ImageOutlineMaker.bat to run the program.

Different images will require different settings to produce good results. For instance, an image with less abrupt changes in contrast or color variety will likely require lower color tolerance values. Larger images will likely require larger values for the pixel check distance and noise removal cluster size. Note that these examples will not apply to all images, however. Adjusting the different values for different images will give a good feel for the settings your specific image might need.

Note that this application's folder structure includes a slimmed down version of OpenJDK JDK 15.0.2. This allows users to run the application without installing this version of Java. For any users who have this JDK however, if you have the JDK's bin folder included in your system's path variable, the only file necessary to run the program is ImageOutlineMaker.jar (located in the Program subfolder) and the other files may be removed.
